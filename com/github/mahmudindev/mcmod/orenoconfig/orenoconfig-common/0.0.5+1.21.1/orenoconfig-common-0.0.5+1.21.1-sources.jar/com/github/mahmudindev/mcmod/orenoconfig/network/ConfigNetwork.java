package com.github.mahmudindev.mcmod.orenoconfig.network;

import com.github.mahmudindev.mcmod.orenocommons.network.UnifiedNetwork;
import com.github.mahmudindev.mcmod.orenocommons.network.UnifiedNetworkPacket;
import com.github.mahmudindev.mcmod.orenocommons.network.UnifiedNetworkUtility;
import com.github.mahmudindev.mcmod.orenoconfig.OrenoConfig;
import com.github.mahmudindev.mcmod.orenoconfig.config.network.ModCommonConfigPacket;
import com.github.mahmudindev.mcmod.orenoconfig.network.packet.ConfigPacket;
import com.github.mahmudindev.mcmod.orenoevents.event.events.PlayerEvents;
import io.netty.buffer.Unpooled;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.server.MinecraftServer;
import java.util.HashMap;
import java.util.Map;

public class ConfigNetwork {
    public static final class_2960 CHANNEL_NAME = class_2960.method_60655(
            OrenoConfig.MOD_ID,
            "default"
    );
    private static final Map<class_2960, ConfigPacket> PACKETS = new HashMap<>();

    public static void init() {
        registerPacket(
                class_2960.method_60655(OrenoConfig.MOD_ID, "common"),
                new ModCommonConfigPacket()
        );

        UnifiedNetwork.registerClientPacketCodec(Packet.TYPE, Packet.STREAM_CODEC);
        UnifiedNetwork.registerServerPacketCodec(Packet.TYPE, Packet.STREAM_CODEC);
        UnifiedNetwork.registerServerPacketReceiver(
                Packet.TYPE,
                (ctx, value) -> {
                    class_2540 buf = new class_2540(Unpooled.buffer());
                    buf.method_52983(value.bytes());
                    handlePackets(ctx, buf);
                    buf.release();
                }
        );

        PlayerEvents.DISCONNECT.register(ConfigNetwork::onServerPlayerDisconnect);
    }

    public static void registerPacket(class_2960 id, ConfigPacket packet) {
        if (PACKETS.containsKey(id)) {
            throw new IllegalStateException("Config packet already exists!");
        }

        PACKETS.put(id, packet);
    }

    public static ConfigPacket getPacket(class_2960 id) {
        return PACKETS.get(id);
    }

    public static Map<class_2960, ConfigPacket> getPackets() {
        return PACKETS;
    }

    private static void handlePackets(
            UnifiedNetworkPacket.Context ctx,
            class_2540 buf
    ) {
        Map<class_2960, ConfigPacket> packets = new HashMap<>();

        class_3222 serverPlayer = ctx.player();

        int count = buf.method_10816();
        for (int i = 0; i < count; i++) {
            class_2960 id = buf.method_10810();

            class_2540 bufX = new class_2540(Unpooled.buffer());

            int readableBytes = buf.method_10816();
            buf.method_52957(bufX, readableBytes);

            ConfigPacket packet = PACKETS.get(id);
            if (packet != null) {
                packet.decodeRequirements(bufX, serverPlayer);
                packets.put(id, packet);
            }

            bufX.release();
        }

        class_2540 bufX = new class_2540(Unpooled.buffer());

        UnifiedNetworkUtility.writeCompressedBuffer(bufX, bufZ -> {
            MinecraftServer server = ctx.server();

            bufZ.method_10804(packets.size());
            packets.forEach((id, packet) -> {
                bufZ.method_10812(id);
                packet.encode(bufZ, server, serverPlayer);
            });
        });

        byte[] bytes = new byte[bufX.readableBytes()];
        bufX.method_52979(bytes);
        UnifiedNetwork.sendPacketToPlayer(serverPlayer, new Packet(bytes));
    }

    private static void onServerPlayerDisconnect(class_3222 serverPlayer) {
        PACKETS.forEach((id, packet) -> {
            packet.onServerPlayerDisconnect(serverPlayer);
        });
    }

    public record Packet(byte[] bytes) implements class_8710 {
        public static final class_9154<Packet> TYPE = new class_9154<>(CHANNEL_NAME);
        public static final class_9139<class_9129, Packet> STREAM_CODEC = class_9139.method_56434(
                class_9139.method_56437(
                        class_2540::method_52983,
                        buf -> {
                            byte[] bytes = new byte[buf.readableBytes()];
                            buf.method_52979(bytes);
                            return bytes;
                        }
                ),
                Packet::bytes,
                Packet::new
        );

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return TYPE;
        }
    }
}
