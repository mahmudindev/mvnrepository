package com.github.mahmudindev.mcmod.orenoconfig.network.packet;

import net.minecraft.class_2540;
import net.minecraft.class_310;
import net.minecraft.class_3222;
import net.minecraft.class_746;
import net.minecraft.server.MinecraftServer;

public interface ConfigPacket {
    default void encodeRequirements(class_2540 buf, class_746 localPlayer) {
    }

    default void decodeRequirements(class_2540 buf, class_3222 serverPlayer) {
    }

    void encode(class_2540 buf, MinecraftServer server, class_3222 player);

    default void writeValue(class_2540 buf, Object value) {
        ConfigPacketParser.writeValue(buf, value);
    }

    void decode(class_2540 buf, class_310 client);

    default Object readValue(class_2540 buf) {
        return ConfigPacketParser.readValue(buf);
    }

    default void onClientPlayerDisconnect(class_746 localPlayer) {
    }

    default void onServerPlayerDisconnect(class_3222 serverPlayer) {
    }
}
