package com.github.mahmudindev.mcmod.orenoconfig.network;

import com.github.mahmudindev.mcmod.orenocommons.network.UnifiedNetwork;
import com.github.mahmudindev.mcmod.orenoconfig.OrenoConfig;
import com.github.mahmudindev.mcmod.orenoconfig.config.network.ModCommonConfigPacket;
import com.github.mahmudindev.mcmod.orenoconfig.network.packet.ConfigPacket;
import com.github.mahmudindev.mcmod.orenoevents.event.common.PlayerEvents;
import io.netty.buffer.Unpooled;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.HashMap;
import java.util.Map;

public class ConfigNetwork {
    public static final class_2960 CHANNEL_NAME = new class_2960(
            OrenoConfig.MOD_ID,
            "default"
    );
    private static final Map<class_2960, ConfigPacket> PACKETS = new HashMap<>();

    public static void init() {
        registerPacket(
                new class_2960(OrenoConfig.MOD_ID, "common"),
                new ModCommonConfigPacket()
        );

        UnifiedNetwork.registerServerPacketReceiver(CHANNEL_NAME, ConfigNetwork::handlePackets);

        PlayerEvents.DISCONNECT.register(ConfigNetwork::onServerPlayerDisconnect);
    }

    public static void registerPacket(class_2960 id, ConfigPacket packet) {
        if (PACKETS.containsKey(id)) {
            throw new IllegalStateException("Config packet already exists!");
        }

        PACKETS.put(id, packet);
    }

    public static ConfigPacket getPacket(class_2960 id) {
        return PACKETS.get(id);
    }

    public static Map<class_2960, ConfigPacket> getPackets() {
        return PACKETS;
    }

    private static void handlePackets(
            MinecraftServer server,
            class_3222 serverPlayer,
            class_2540 buf
    ) {
        Map<class_2960, ConfigPacket> packets = new HashMap<>();

        int count = buf.method_10816();
        for (int i = 0; i < count; i++) {
            class_2960 id = buf.method_10810();

            int readableBytes = buf.method_10816();
            class_2540 bufX = new class_2540(buf.readSlice(readableBytes));

            ConfigPacket packet = PACKETS.get(id);
            if (packet != null) {
                packet.decodeRequirements(bufX, serverPlayer);
                packets.put(id, packet);
                continue;
            }

            bufX.release();
        }

        class_2540 bufX = new class_2540(Unpooled.buffer());

        UnifiedNetwork.writeCompressedBuffer(bufX, bufZ -> {
            bufZ.method_10804(packets.size());
            packets.forEach((id, packet) -> {
                bufZ.method_10812(id);
                packet.encode(bufZ, server, serverPlayer);
            });
        });

        UnifiedNetwork.sendPacketToPlayer(serverPlayer, ConfigNetwork.CHANNEL_NAME, bufX);
    }

    private static void onServerPlayerDisconnect(class_3222 serverPlayer) {
        PACKETS.forEach((id, packet) -> {
            packet.onServerPlayerDisconnect(serverPlayer);
        });
    }
}
