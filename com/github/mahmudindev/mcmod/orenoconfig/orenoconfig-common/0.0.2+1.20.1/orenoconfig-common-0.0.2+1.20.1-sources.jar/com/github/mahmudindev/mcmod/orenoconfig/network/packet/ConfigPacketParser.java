package com.github.mahmudindev.mcmod.orenoconfig.network.packet;

import com.github.mahmudindev.mcmod.orenoconfig.OrenoConfig;
import io.netty.buffer.Unpooled;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.*;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_4076;

public class ConfigPacketParser {
    private static final Map<class_2960, ValueParser<?>> VALUE_PARSERS = new HashMap<>();
    private static final Map<Class<?>, class_2960> VALUE_PARSER_ID_CLASSES = new HashMap<>();
    private static final class_2960 OBJ_ARR_VALUE_PARSER_ID;

    public static <T> void registerValueParser(
            class_2960 id,
            Class<T> clazz,
            ValueParser<T> valueParser
    ) {
        VALUE_PARSERS.put(id, valueParser);
        VALUE_PARSER_ID_CLASSES.put(clazz, id);
    }

    public static void writeValue(class_2540 buf, Object value) {
        if (value == null) {
            buf.writeBoolean(false);
            return;
        }

        class_2540 bufX = new class_2540(Unpooled.buffer());

        class_2960 id = getValueParserId(value.getClass());
        if (id == null) {
            buf.writeBoolean(false);
            return;
        }
        buf.writeBoolean(true);
        bufX.method_10812(id);
        ((ValueParser) getValueParser(id)).encode(bufX, value);

        buf.method_10804(bufX.readableBytes());
        buf.writeBytes(bufX);
        bufX.release();
    }

    public static Object readValue(class_2540 buf) {
        boolean hasValue = buf.readBoolean();
        if (!hasValue) {
            return null;
        }

        int readableBytes = buf.method_10816();
        class_2540 bufX = new class_2540(buf.readSlice(readableBytes));

        class_2960 id = bufX.method_10810();
        ValueParser valueParser = getValueParser(id);
        if (valueParser != null) {
            Object o = valueParser.decode(bufX);
            bufX.release();
            return o;
        }

        bufX.release();
        return null;
    }

    private static ValueParser<?> getValueParser(class_2960 id) {
        return VALUE_PARSERS.get(id);
    }

    private static class_2960 getValueParserId(Class<?> clazz) {
        class_2960 id = VALUE_PARSER_ID_CLASSES.get(clazz);
        if (id != null) {
            return id;
        }

        if (clazz.isArray() && !clazz.getComponentType().isPrimitive()) {
            return OBJ_ARR_VALUE_PARSER_ID;
        }

        for (Class<?> claxx : VALUE_PARSER_ID_CLASSES.keySet()) {
            if (claxx.isAssignableFrom(clazz)) {
                class_2960 idX = VALUE_PARSER_ID_CLASSES.get(claxx);
                VALUE_PARSER_ID_CLASSES.put(claxx, idX);
                return idX;
            }
        }

        return null;
    }

    public interface ValueParser<T> {
        void encode(class_2540 buf, T value);

        T decode(class_2540 buf);
    }

    static {
        registerValueParser(
                new class_2960(OrenoConfig.MOD_ID, "byte"),
                Byte.class,
                new ValueParser<>() {
                    @Override
                    public void encode(class_2540 buf, Byte value) {
                        buf.writeByte(value);
                    }

                    @Override
                    public Byte decode(class_2540 buf) {
                        return buf.readByte();
                    }
                }
        );

        registerValueParser(
                new class_2960(OrenoConfig.MOD_ID, "byte_arr"),
                byte[].class,
                new ValueParser<>() {
                    @Override
                    public void encode(class_2540 buf, byte[] value) {
                        buf.method_10813(value);
                    }

                    @Override
                    public byte[] decode(class_2540 buf) {
                        return buf.method_10795();
                    }
                }
        );

        registerValueParser(
                new class_2960(OrenoConfig.MOD_ID, "short"),
                Short.class,
                new ValueParser<>() {
                    @Override
                    public void encode(class_2540 buf, Short value) {
                        buf.writeShort(value);
                    }

                    @Override
                    public Short decode(class_2540 buf) {
                        return buf.readShort();
                    }
                }
        );

        registerValueParser(
                new class_2960(OrenoConfig.MOD_ID, "short_arr"),
                short[].class,
                new ValueParser<>() {
                    @Override
                    public void encode(class_2540 buf, short[] value) {
                        buf.method_10804(value.length);

                        for (short v : value) {
                            buf.writeShort(v);
                        }
                    }

                    @Override
                    public short[] decode(class_2540 buf) {
                        int length = buf.method_10816();

                        short[] arr = new short[length];
                        for (int i = 0; i < length; i++) {
                            arr[i] = buf.readShort();
                        }
                        return arr;
                    }
                }
        );

        registerValueParser(
                new class_2960(OrenoConfig.MOD_ID, "int"),
                Integer.class,
                new ValueParser<>() {
                    @Override
                    public void encode(class_2540 buf, Integer value) {
                        buf.method_10804(value);
                    }

                    @Override
                    public Integer decode(class_2540 buf) {
                        return buf.method_10816();
                    }
                }
        );

        registerValueParser(
                new class_2960(OrenoConfig.MOD_ID, "int_arr"),
                int[].class,
                new ValueParser<>() {
                    @Override
                    public void encode(class_2540 buf, int[] value) {
                        buf.method_10806(value);
                    }

                    @Override
                    public int[] decode(class_2540 buf) {
                        return buf.method_10787();
                    }
                }
        );

        registerValueParser(
                new class_2960(OrenoConfig.MOD_ID, "long"),
                Long.class,
                new ValueParser<>() {
                    @Override
                    public void encode(class_2540 buf, Long value) {
                        buf.method_10791(value);
                    }

                    @Override
                    public Long decode(class_2540 buf) {
                        return buf.method_10792();
                    }
                }
        );

        registerValueParser(
                new class_2960(OrenoConfig.MOD_ID, "long_arr"),
                long[].class,
                new ValueParser<>() {
                    @Override
                    public void encode(class_2540 buf, long[] value) {
                        buf.method_10804(value.length);

                        for (long v : value) {
                            buf.method_10791(v);
                        }
                    }

                    @Override
                    public long[] decode(class_2540 buf) {
                        int length = buf.method_10816();

                        long[] arr = new long[length];
                        for (int i = 0; i < length; i++) {
                            arr[i] = buf.method_10792();
                        }
                        return arr;
                    }
                }
        );

        registerValueParser(
                new class_2960(OrenoConfig.MOD_ID, "float"),
                Float.class,
                new ValueParser<>() {
                    @Override
                    public void encode(class_2540 buf, Float value) {
                        buf.writeFloat(value);
                    }

                    @Override
                    public Float decode(class_2540 buf) {
                        return buf.readFloat();
                    }
                }
        );

        registerValueParser(
                new class_2960(OrenoConfig.MOD_ID, "float_arr"),
                float[].class,
                new ValueParser<>() {
                    @Override
                    public void encode(class_2540 buf, float[] value) {
                        buf.method_10804(value.length);

                        for (float v : value) {
                            buf.writeFloat(v);
                        }
                    }

                    @Override
                    public float[] decode(class_2540 buf) {
                        int length = buf.method_10816();

                        float[] arr = new float[length];
                        for (int i = 0; i < length; i++) {
                            arr[i] = buf.readFloat();
                        }
                        return arr;
                    }
                }
        );

        registerValueParser(
                new class_2960(OrenoConfig.MOD_ID, "double"),
                Double.class,
                new ValueParser<>() {
                    @Override
                    public void encode(class_2540 buf, Double value) {
                        buf.writeDouble(value);
                    }

                    @Override
                    public Double decode(class_2540 buf) {
                        return buf.readDouble();
                    }
                }
        );

        registerValueParser(
                new class_2960(OrenoConfig.MOD_ID, "double_arr"),
                double[].class,
                new ValueParser<>() {
                    @Override
                    public void encode(class_2540 buf, double[] value) {
                        buf.method_10804(value.length);

                        for (double v : value) {
                            buf.writeDouble(v);
                        }
                    }

                    @Override
                    public double[] decode(class_2540 buf) {
                        int length = buf.method_10816();

                        double[] arr = new double[length];
                        for (int i = 0; i < length; i++) {
                            arr[i] = buf.readDouble();
                        }
                        return arr;
                    }
                }
        );

        registerValueParser(
                new class_2960(OrenoConfig.MOD_ID, "char"),
                Character.class,
                new ValueParser<>() {
                    @Override
                    public void encode(class_2540 buf, Character value) {
                        buf.writeChar(value);
                    }

                    @Override
                    public Character decode(class_2540 buf) {
                        return buf.readChar();
                    }
                }
        );

        registerValueParser(
                new class_2960(OrenoConfig.MOD_ID, "char_arr"),
                char[].class,
                new ValueParser<>() {
                    @Override
                    public void encode(class_2540 buf, char[] value) {
                        buf.method_10804(value.length);

                        for (char v : value) {
                            buf.writeChar(v);
                        }
                    }

                    @Override
                    public char[] decode(class_2540 buf) {
                        int length = buf.method_10816();

                        char[] arr = new char[length];
                        for (int i = 0; i < length; i++) {
                            arr[i] = buf.readChar();
                        }
                        return arr;
                    }
                }
        );

        registerValueParser(
                new class_2960(OrenoConfig.MOD_ID, "boolean"),
                Boolean.class,
                new ValueParser<>() {
                    @Override
                    public void encode(class_2540 buf, Boolean value) {
                        buf.writeBoolean(value);
                    }

                    @Override
                    public Boolean decode(class_2540 buf) {
                        return buf.readBoolean();
                    }
                }
        );

        registerValueParser(
                new class_2960(OrenoConfig.MOD_ID, "boolean_arr"),
                boolean[].class,
                new ValueParser<>() {
                    @Override
                    public void encode(class_2540 buf, boolean[] value) {
                        buf.method_10804(value.length);

                        for (boolean v : value) {
                            buf.writeBoolean(v);
                        }
                    }

                    @Override
                    public boolean[] decode(class_2540 buf) {
                        int length = buf.method_10816();

                        boolean[] arr = new boolean[length];
                        for (int i = 0; i < length; i++) {
                            arr[i] = buf.readBoolean();
                        }
                        return arr;
                    }
                }
        );

        registerValueParser(
                new class_2960(OrenoConfig.MOD_ID, "string"),
                String.class,
                new ValueParser<>() {
                    @Override
                    public void encode(class_2540 buf, String value) {
                        buf.method_10814(value);
                    }

                    @Override
                    public String decode(class_2540 buf) {
                        return buf.method_19772();
                    }
                }
        );

        registerValueParser(
                new class_2960(OrenoConfig.MOD_ID, "list"),
                List.class,
                new ValueParser<>() {
                    @Override
                    public void encode(class_2540 buf, List value) {
                        buf.method_10804(value.size());

                        for (Object v : value) {
                            writeValue(buf, v);
                        }
                    }

                    @Override
                    public List decode(class_2540 buf) {
                        int size = buf.method_10816();

                        List<Object> list = new ArrayList<>(size);
                        for (int i = 0; i < size; i++) {
                            list.add(readValue(buf));
                        }
                        return list;
                    }
                }
        );

        registerValueParser(
                new class_2960(OrenoConfig.MOD_ID, "set"),
                Set.class,
                new ValueParser<>() {
                    @Override
                    public void encode(class_2540 buf, Set value) {
                        buf.method_10804(value.size());

                        for (Object v : value) {
                            writeValue(buf, v);
                        }
                    }

                    @Override
                    public Set decode(class_2540 buf) {
                        int size = buf.method_10816();

                        Set<Object> set = new HashSet<>(size);
                        for (int i = 0; i < size; i++) {
                            set.add(readValue(buf));
                        }
                        return set;
                    }
                }
        );

        registerValueParser(
                new class_2960(OrenoConfig.MOD_ID, "map"),
                Map.class,
                new ValueParser<>() {
                    @Override
                    public void encode(class_2540 buf, Map value) {
                        buf.method_10804(value.size());

                        for (Object entry : value.entrySet()) {
                            writeValue(buf, ((Map.Entry) entry).getKey());
                            writeValue(buf, ((Map.Entry) entry).getValue());
                        }
                    }

                    @Override
                    public Map decode(class_2540 buf) {
                        int size = buf.method_10816();

                        Map<Object, Object> map = new HashMap<>(size);
                        for (int i = 0; i < size; i++) {
                            Object k = readValue(buf);
                            Object v = readValue(buf);
                            map.put(k, v);
                        }
                        return map;
                    }
                }
        );

        registerValueParser(
                new class_2960(OrenoConfig.MOD_ID, "uuid"),
                UUID.class,
                new ValueParser<>() {
                    @Override
                    public void encode(class_2540 buf, UUID value) {
                        buf.method_10797(value);
                    }

                    @Override
                    public UUID decode(class_2540 buf) {
                        return buf.method_10790();
                    }
                }
        );

        registerValueParser(
                new class_2960(OrenoConfig.MOD_ID, "vector3f"),
                Vector3f.class,
                new ValueParser<>() {
                    @Override
                    public void encode(class_2540 buf, Vector3f value) {
                        buf.method_49068(value);
                    }

                    @Override
                    public Vector3f decode(class_2540 buf) {
                        return buf.method_49069();
                    }
                }
        );

        registerValueParser(
                new class_2960(OrenoConfig.MOD_ID, "quaternionf"),
                Quaternionf.class,
                new ValueParser<>() {
                    @Override
                    public void encode(class_2540 buf, Quaternionf value) {
                        buf.method_49067(value);
                    }

                    @Override
                    public Quaternionf decode(class_2540 buf) {
                        return buf.method_49070();
                    }
                }
        );

        registerValueParser(
                new class_2960(OrenoConfig.MOD_ID, "resourceLocation"),
                class_2960.class,
                new ValueParser<>() {
                    @Override
                    public void encode(class_2540 buf, class_2960 value) {
                        buf.method_10812(value);
                    }

                    @Override
                    public class_2960 decode(class_2540 buf) {
                        return buf.method_10810();
                    }
                }
        );

        registerValueParser(
                new class_2960(OrenoConfig.MOD_ID, "blockPos"),
                class_2338.class,
                new ValueParser<>() {
                    @Override
                    public void encode(class_2540 buf, class_2338 value) {
                        buf.method_10807(value);
                    }

                    @Override
                    public class_2338 decode(class_2540 buf) {
                        return buf.method_10811();
                    }
                }
        );

        registerValueParser(
                new class_2960(OrenoConfig.MOD_ID, "chunkPos"),
                class_1923.class,
                new ValueParser<>() {
                    @Override
                    public void encode(class_2540 buf, class_1923 value) {
                        buf.method_36130(value);
                    }

                    @Override
                    public class_1923 decode(class_2540 buf) {
                        return buf.method_36133();
                    }
                }
        );

        registerValueParser(
                new class_2960(OrenoConfig.MOD_ID, "sectionPos"),
                class_4076.class,
                new ValueParser<>() {
                    @Override
                    public void encode(class_2540 buf, class_4076 value) {
                        buf.method_36131(value);
                    }

                    @Override
                    public class_4076 decode(class_2540 buf) {
                        return buf.method_19456();
                    }
                }
        );

        registerValueParser(
                new class_2960(OrenoConfig.MOD_ID, "nbt"),
                class_2487.class,
                new ValueParser<>() {
                    @Override
                    public void encode(class_2540 buf, class_2487 value) {
                        buf.method_10794(value);
                    }

                    @Override
                    public class_2487 decode(class_2540 buf) {
                        return buf.method_10798();
                    }
                }
        );

        OBJ_ARR_VALUE_PARSER_ID = new class_2960(OrenoConfig.MOD_ID, "obj_arr");
        registerValueParser(
                OBJ_ARR_VALUE_PARSER_ID,
                Object[].class,
                new ValueParser<>() {
                    @Override
                    public void encode(class_2540 buf, Object[] value) {
                        buf.method_10804(value.length);

                        for (Object v : value) {
                            writeValue(buf, v);
                        }
                    }

                    @Override
                    public Object[] decode(class_2540 buf) {
                        int length = buf.method_10816();

                        Object[] arr = new Object[length];
                        for (int i = 0; i < length; i++) {
                            arr[i] = readValue(buf);
                        }
                        return arr;
                    }
                }
        );
    }
}
