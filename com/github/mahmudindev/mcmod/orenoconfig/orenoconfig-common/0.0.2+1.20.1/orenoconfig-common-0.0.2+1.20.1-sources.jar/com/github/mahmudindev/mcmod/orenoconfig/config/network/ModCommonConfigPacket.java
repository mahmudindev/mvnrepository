package com.github.mahmudindev.mcmod.orenoconfig.config.network;

import com.github.mahmudindev.mcmod.orenoconfig.config.ConfigNode;
import com.github.mahmudindev.mcmod.orenoconfig.config.configs.ModCommonConfig;
import io.netty.buffer.Unpooled;
import net.minecraft.class_2540;
import net.minecraft.class_310;
import net.minecraft.class_3222;
import net.minecraft.class_746;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class ModCommonConfigPacket extends ModConfigPacket {
    private static final Map<String, Handler> HANDLERS = new HashMap<>();
    private static final Map<class_3222, Set<String>> PLAYER_CONFIGS = new HashMap<>();

    @Override
    public void encodeRequirements(class_2540 buf, class_746 localPlayer) {
        buf.method_10804(HANDLERS.size());
        HANDLERS.forEach((key, handler) -> {
            buf.method_10814(key);
        });
    }

    @Override
    public void decodeRequirements(class_2540 buf, class_3222 serverPlayer) {
        int count = buf.method_10816();
        for (int i = 0; i < count; i++) {
            String key = buf.method_19772();

            Set<String> configs = PLAYER_CONFIGS.computeIfAbsent(
                    serverPlayer,
                    keyX -> new HashSet<>()
            );

            if (HANDLERS.containsKey(key)) {
                configs.add(key);
            }

        }
    }

    @Override
    public void encode(class_2540 buf, MinecraftServer server, class_3222 player) {
        Map<String, Handler> handlers = new HashMap<>();

        HANDLERS.forEach((key, handler) -> {
            Set<String> configs = PLAYER_CONFIGS.get(player);
            if (configs == null || !configs.contains(key)) {
                return;
            }

            handlers.put(key, handler);
        });

        buf.method_10804(handlers.size());
        handlers.forEach((key, handler) -> {
            buf.method_10814(key);

            class_2540 bufX = new class_2540(Unpooled.buffer());

            this.encodeNodeTree(bufX, handler.getGetterNode());
            buf.method_10804(bufX.readableBytes());
            buf.writeBytes(bufX);

            bufX.release();
        });
    }

    @Override
    public void decode(class_2540 buf, class_310 client) {
        int count = buf.method_10816();
        for (int i = 0; i < count; i++) {
            String key = buf.method_19772();

            int readableBytes = buf.method_10816();
            class_2540 bufX = new class_2540(buf.readSlice(readableBytes));

            Handler handler = HANDLERS.get(key);
            if (handler != null) {
                this.decodeNodeTree(bufX, handler.getSynchronizedGetterNode());
            }

            bufX.release();
        }
    }

    @Override
    public void onClientPlayerDisconnect(class_746 localPlayer) {
        ModCommonConfig.clearServerSync();
    }

    @Override
    public void onServerPlayerDisconnect(class_3222 serverPlayer) {
        PLAYER_CONFIGS.remove(serverPlayer);
    }

    public static void registerHandler(String name, Handler handler) {
        HANDLERS.put(name, handler);
    }

    public interface Handler {
        ConfigNode getGetterNode();

        ConfigNode getSynchronizedGetterNode();
    }
}
