package com.github.mahmudindev.mcmod.orenoconfig.config.network;

import com.github.mahmudindev.mcmod.orenoconfig.config.ConfigNode;
import com.github.mahmudindev.mcmod.orenoconfig.network.packet.ConfigPacket;
import java.util.Map;
import net.minecraft.class_2540;

public abstract class ModConfigPacket implements ConfigPacket {
    protected void encodeNodeTree(class_2540 buf, ConfigNode node) {
        Map<String, ConfigNode> children = node.getChildren();

        buf.method_10804(children.size());
        children.forEach((key, value) -> {
            buf.method_10814(key);

            if (value.isLeaf()) {
                this.writeValue(buf, value);
            }

            this.encodeNodeTree(buf, value);
        });
    }

    protected void decodeNodeTree(class_2540 buf, ConfigNode node) {
        int count = buf.method_10816();
        for (int i = 0; i < count; i++) {
            String key = buf.method_19772();
            ConfigNode child = node.getOrCreatePath(new String[]{key}, 0);

            if (child.isLeaf()) {
                child.setValue(this.readValue(buf));
            }

            this.decodeNodeTree(buf, child);
        }
    }
}
