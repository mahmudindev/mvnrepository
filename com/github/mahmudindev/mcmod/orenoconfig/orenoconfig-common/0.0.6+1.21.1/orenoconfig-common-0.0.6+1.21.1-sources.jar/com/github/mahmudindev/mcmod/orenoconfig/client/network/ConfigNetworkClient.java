package com.github.mahmudindev.mcmod.orenoconfig.client.network;

import com.github.mahmudindev.mcmod.orenocommons.client.network.UnifiedNetworkClient;
import com.github.mahmudindev.mcmod.orenocommons.client.network.UnifiedNetworkPacketClient;
import com.github.mahmudindev.mcmod.orenocommons.network.UnifiedNetworkUtility;
import com.github.mahmudindev.mcmod.orenoconfig.network.ConfigNetwork;
import com.github.mahmudindev.mcmod.orenoconfig.network.packet.ConfigPacket;
import com.github.mahmudindev.mcmod.orenoevents.client.event.events.ClientPlayerEvents;
import io.netty.buffer.Unpooled;
import java.util.Map;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_746;

public class ConfigNetworkClient {
    public static void init() {
        ClientPlayerEvents.JOIN.register(ConfigNetworkClient::onClientPlayerJoin);

        UnifiedNetworkClient.registerClientPacketReceiver(
                ConfigNetwork.Packet.TYPE,
                (ctx, value) -> {
                    class_2540 buf = new class_2540(Unpooled.buffer());
                    buf.method_52983(value.bytes());
                    handlePackets(ctx, buf);
                    buf.release();
                }
        );

        ClientPlayerEvents.DISCONNECT.register(ConfigNetworkClient::onClientPlayerDisconnect);
    }

    private static void onClientPlayerJoin(class_746 localPlayer) {
        if (localPlayer.method_5682() != null) {
            return;
        }

        if (!UnifiedNetworkClient.canSendPacketToServer(ConfigNetwork.Packet.TYPE)) {
            return;
        }

        class_2540 buf = new class_2540(Unpooled.buffer());

        Map<class_2960, ConfigPacket> packets = ConfigNetwork.getPackets();
        buf.method_10804(packets.size());
        packets.forEach((id, packet) -> {
            buf.method_10812(id);

            class_2540 bufX = new class_2540(Unpooled.buffer());

            packet.encodeRequirements(bufX, localPlayer);
            buf.method_10804(bufX.readableBytes());
            buf.method_52975(bufX);

            bufX.release();
        });

        byte[] bytes = new byte[buf.readableBytes()];
        buf.method_52979(bytes);
        UnifiedNetworkClient.sendPacketToServer(new ConfigNetwork.Packet(bytes));
    }

    private static void handlePackets(
            UnifiedNetworkPacketClient.Context ctx,
            class_2540 buf
    ) {
        UnifiedNetworkUtility.readCompressedBuffer(buf, bufX -> {
            class_310 client = ctx.client();

            int count = bufX.method_10816();
            for (int i = 0; i < count; i++) {
                class_2960 id = bufX.method_10810();
                ConfigPacket packet = ConfigNetwork.getPacket(id);
                packet.decode(bufX, client);
            }
        }, 2_048_000);
    }

    private static void onClientPlayerDisconnect(class_746 localPlayer) {
        Map<class_2960, ConfigPacket> packets = ConfigNetwork.getPackets();
        packets.forEach((id, packet) -> {
            packet.onClientPlayerDisconnect(localPlayer);
        });
    }
}
