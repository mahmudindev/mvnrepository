package com.github.mahmudindev.mcmod.orenoevents.fabric.client.event;

import com.github.mahmudindev.mcmod.orenoevents.OrenoEvents;
import com.github.mahmudindev.mcmod.orenoevents.client.event.events.ClientEvents;
import com.github.mahmudindev.mcmod.orenoevents.client.event.events.ClientPlayerEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_3300;

public class EventsFabricClient {
    public static void init() {
        clientEvents();
        playerEvents();
    }

    private static void clientEvents() {
        ResourceManagerHelper
                .get(class_3264.field_14188)
                .registerReloadListener(new SimpleSynchronousResourceReloadListener() {
                    @Override
                    public class_2960 getFabricId() {
                        return class_2960.method_60655(
                                OrenoEvents.MOD_ID,
                                "default"
                        );
                    }

                    @Override
                    public void method_14491(class_3300 resourceManager) {
                        ClientEvents.RESOURCE_MANAGER_RELOAD.invoker(clientResourceReload -> {
                            clientResourceReload.onResourceManagerReload(resourceManager);
                        });
                    }
                });
    }

    private static void playerEvents() {
        ClientPlayConnectionEvents.JOIN.register(((handler, sender, client) -> {
            ClientPlayerEvents.JOIN.invoker(join -> {
                join.onJoin(client.field_1724);
            });
        }));

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            ClientPlayerEvents.DISCONNECT.invoker(disconnect -> {
                disconnect.onDisconnect(client.field_1724);
            });
        });
    }
}
