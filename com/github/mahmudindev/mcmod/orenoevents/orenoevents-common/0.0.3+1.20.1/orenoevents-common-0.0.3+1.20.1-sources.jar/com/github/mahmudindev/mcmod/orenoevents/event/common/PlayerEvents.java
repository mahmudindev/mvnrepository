package com.github.mahmudindev.mcmod.orenoevents.event.common;

import com.github.mahmudindev.mcmod.orenoevents.event.Event;
import net.minecraft.class_3222;

public class PlayerEvents {
    public static final Event<Join> JOIN = new Event<>();
    public static final Event<Disconnect> DISCONNECT = new Event<>();

    @FunctionalInterface
    public interface Join {
        void onJoin(class_3222 serverPlayer);
    }

    @FunctionalInterface
    public interface Disconnect {
        void onDisconnect(class_3222 serverPlayer);
    }
}
