package com.github.mahmudindev.mcmod.orenoevents.event.client;

import com.github.mahmudindev.mcmod.orenoevents.event.Event;
import net.minecraft.class_3300;

public class ClientEvents {
    public static final Event<ResourceManagerReload> RESOURCE_MANAGER_RELOAD = new Event<>();

    @FunctionalInterface
    public interface ResourceManagerReload {
        void onResourceManagerReload(class_3300 resourceManager);
    }
}
