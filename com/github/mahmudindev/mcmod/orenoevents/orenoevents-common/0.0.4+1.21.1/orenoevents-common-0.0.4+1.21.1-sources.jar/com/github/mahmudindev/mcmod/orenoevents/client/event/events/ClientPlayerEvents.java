package com.github.mahmudindev.mcmod.orenoevents.client.event.events;

import com.github.mahmudindev.mcmod.orenoevents.event.Event;
import net.minecraft.class_746;

public class ClientPlayerEvents {
    public static final Event<Join> JOIN = new Event<>();
    public static final Event<Disconnect> DISCONNECT = new Event<>();

    @FunctionalInterface
    public interface Join {
        void onJoin(class_746 localPlayer);
    }

    @FunctionalInterface
    public interface Disconnect {
        void onDisconnect(class_746 localPlayer);
    }
}
