package com.github.mahmudindev.mcmod.orenocommons.neoforge.platform.services;

import com.github.mahmudindev.mcmod.orenocommons.OrenoCommons;
import com.github.mahmudindev.mcmod.orenocommons.neoforge.network.UnifiedNetworkNeoForge;
import com.github.mahmudindev.mcmod.orenocommons.platform.EnvSide;
import com.github.mahmudindev.mcmod.orenocommons.network.UnifiedNetworkPacket;
import com.github.mahmudindev.mcmod.orenocommons.platform.services.IPlatformHelper;
import net.minecraft.core.Registry;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.ModList;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.fml.loading.FMLLoader;
import net.neoforged.fml.loading.FMLPaths;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.nio.file.Path;
import java.util.function.Supplier;

public class NeoForgePlatformHelper implements IPlatformHelper {
    @Override
    public String getPlatformName() {
        return "Forge";
    }

    @Override
    public Path getGameDir() {
        return FMLPaths.GAMEDIR.get();
    }

    @Override
    public Path getConfigDir() {
        return FMLPaths.CONFIGDIR.get();
    }

    @Override
    public boolean isModLoaded(String id) {
        ModList modList = ModList.get();

        if (modList == null) {
            FMLLoader loader = FMLLoader.getCurrent();

            return loader.getLoadingModList().getModFileById(id) != null;
        }

        return modList.isLoaded(id);
    }

    @Override
    public EnvSide getEnvSide() {
        switch (FMLEnvironment.getDist()) {
            case CLIENT -> {
                return EnvSide.CLIENT;
            }
            case DEDICATED_SERVER -> {
                return EnvSide.DEDICATED_SERVER;
            }
        }

        return null;
    }

    @Override
    public boolean isDevelopmentEnvironment() {
        return !FMLEnvironment.isProduction();
    }

    public static IEventBus getModEventBus(String id) {
        return ModList.get().getModContainerById(id)
                .map(ModContainer::getEventBus)
                .orElseThrow(() -> new IllegalStateException("No mod found with id " + id));
    }

    @Override
    public <T, V extends T> Supplier<V> registerRegistryEntry(
            ResourceKey<? extends Registry<T>> resourceKey,
            Identifier identifier,
            Supplier<? extends V> supplier
    ) {
        DeferredRegister<T> deferredRegister = DeferredRegister.create(
                resourceKey,
                identifier.getNamespace()
        );

        IEventBus eventBus = getModEventBus(OrenoCommons.MOD_ID);
        deferredRegister.register(eventBus);

        return deferredRegister.register(identifier.getPath(), supplier);
    }

    @Override
    public <T extends CustomPacketPayload> void registerClientNetworkPacketCodec(
            CustomPacketPayload.Type<T> type,
            StreamCodec<RegistryFriendlyByteBuf, T> codec
    ) {
        UnifiedNetworkNeoForge.registerPacketCodec(type, codec);
    }

    @Override
    public <T extends CustomPacketPayload> void registerServerNetworkPacketCodec(
            CustomPacketPayload.Type<T> type,
            StreamCodec<RegistryFriendlyByteBuf, T> codec
    ) {
        UnifiedNetworkNeoForge.registerPacketCodec(type, codec);
    }

    @Override
    public <T extends CustomPacketPayload> void registerServerNetworkPacketReceiver(
            CustomPacketPayload.Type<T> type,
            UnifiedNetworkPacket.Handler<T> handler
    ) {
        UnifiedNetworkNeoForge.registerServerNetworkPacketReceiver(type, handler);
    }

    @Override
    public void sendNetworkPacketToPlayer(ServerPlayer player, CustomPacketPayload payload) {
        PacketDistributor.sendToPlayer(player, payload);
    }

    @Override
    public boolean canSendNetworkPacketToPlayer(
            ServerPlayer player,
            CustomPacketPayload.Type<?> type
    ) {
        return player.connection.hasChannel(type);
    }
}
