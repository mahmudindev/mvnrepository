package com.github.mahmudindev.mcmod.orenocommons.neoforge;

import com.github.mahmudindev.mcmod.orenocommons.OrenoCommons;
import net.neoforged.fml.common.Mod;

@Mod(OrenoCommons.MOD_ID)
public final class OrenoCommonsNeoForge {
    public OrenoCommonsNeoForge() {
        // Run our common setup.
        OrenoCommons.init();
    }
}
