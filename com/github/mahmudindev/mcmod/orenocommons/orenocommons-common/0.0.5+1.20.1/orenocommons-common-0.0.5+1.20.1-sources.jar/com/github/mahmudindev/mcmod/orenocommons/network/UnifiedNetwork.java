package com.github.mahmudindev.mcmod.orenocommons.network;

import com.github.mahmudindev.mcmod.orenocommons.OrenoCommonsExpectPlatform;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public class UnifiedNetwork {
    public static void registerServerPacketReceiver(
            class_2960 channelName,
            UnifiedNetworkPacket.Handler handler
    ) {
        OrenoCommonsExpectPlatform.registerServerNetworkPacketReceiver(channelName, handler);
    }

    public static void sendPacketToPlayer(
            class_3222 player,
            class_2960 channelName,
            class_2540 buf
    ) {
        OrenoCommonsExpectPlatform.sendNetworkPacketToPlayer(player, channelName, buf);
    }

    public static boolean canSendPacketToPlayer(
            class_3222 player,
            class_2960 channelName
    ) {
        return OrenoCommonsExpectPlatform.canSendNetworkPacketToPlayer(player, channelName);
    }
}
