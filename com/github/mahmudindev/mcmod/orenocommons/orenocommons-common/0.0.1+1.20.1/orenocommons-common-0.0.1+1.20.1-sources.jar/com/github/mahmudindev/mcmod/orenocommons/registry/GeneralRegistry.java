package com.github.mahmudindev.mcmod.orenocommons.registry;

import com.github.mahmudindev.mcmod.orenocommons.OrenoCommonsExpectPlatform;
import java.util.function.Supplier;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;

public class GeneralRegistry {
    public static <T, V extends T> Supplier<V> registerEntry(
            class_5321<? extends class_2378<T>> resourceKey,
            class_2960 resourceLocation,
            Supplier<? extends V> supplier
    ) {
        return OrenoCommonsExpectPlatform.registerRegistryEntry(
                resourceKey,
                resourceLocation,
                supplier
        );
    }
}
