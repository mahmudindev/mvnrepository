package com.github.mahmudindev.mcmod.orenocommons.network;

import com.github.mahmudindev.mcmod.orenocommons.OrenoCommons;
import com.github.mahmudindev.mcmod.orenocommons.platform.services.Services;
import io.netty.buffer.Unpooled;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.function.Consumer;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public class UnifiedNetwork {
    public static void registerServerPacketReceiver(
            class_2960 channelName,
            UnifiedNetworkPacket.Handler handler
    ) {
        Services.PLATFORM.registerServerNetworkPacketReceiver(channelName, handler);
    }

    public static void sendPacketToPlayer(
            class_3222 player,
            class_2960 channelName,
            class_2540 buf
    ) {
        Services.PLATFORM.sendNetworkPacketToPlayer(player, channelName, buf);
    }

    public static boolean canSendPacketToPlayer(
            class_3222 player,
            class_2960 channelName
    ) {
        return Services.PLATFORM.canSendNetworkPacketToPlayer(player, channelName);
    }

    public static void writeCompressedBuffer(
            class_2540 buf,
            Consumer<class_2540> payload
    ) {
        class_2540 bufX = new class_2540(Unpooled.buffer());

        try {
            payload.accept(bufX);

            byte[] bytes = new byte[bufX.readableBytes()];
            bufX.readBytes(bytes);

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            try (GZIPOutputStream gzip = new GZIPOutputStream(baos)) {
                gzip.write(bytes);
                gzip.finish();
            } catch (IOException e) {
                OrenoCommons.LOGGER.error("Failed to write compressed packet", e);
                return;
            }

            byte[] bytesX = baos.toByteArray();
            buf.method_10804(bytesX.length);
            buf.writeBytes(bytesX);
        } finally {
            bufX.release();
        }
    }

    public static void readCompressedBuffer(
            class_2540 buf,
            Consumer<class_2540> payload
    ) {
        class_2540 bufX = new class_2540(Unpooled.buffer());

        try {
            int length = buf.method_10816();
            byte[] bytes = new byte[length];
            buf.readBytes(bytes);

            ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
            try (GZIPInputStream gzip = new GZIPInputStream(bais)) {
                byte[] bytesX = gzip.readAllBytes();
                bufX.writeBytes(bytesX);
            } catch (IOException e) {
                OrenoCommons.LOGGER.error("Failed to read compressed packet", e);
                return;
            }

            payload.accept(bufX);
        } finally {
            bufX.release();
        }
    }
}
