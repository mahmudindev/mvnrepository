package com.github.mahmudindev.mcmod.orenocommons.client;

import com.github.mahmudindev.mcmod.orenocommons.client.network.UnifiedNetworkPacketClient;
import dev.architectury.injectables.annotations.ExpectPlatform;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

public class OrenoCommonsClientExpectPlatform {
    @ExpectPlatform
    public static void registerClientNetworkPacketReceiver(
            class_2960 channelName,
            UnifiedNetworkPacketClient.Handler handler
    ) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void sendNetworkPacketToServer(
            class_2960 channelName,
            class_2540 buf
    ) {
        throw new AssertionError();
    }
}
