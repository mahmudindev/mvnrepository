package com.github.mahmudindev.mcmod.orenocommons.client.network;

import com.github.mahmudindev.mcmod.orenocommons.client.platform.services.ClientServices;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

public class UnifiedNetworkClient {
    public static void registerClientPacketReceiver(
            class_2960 channelName,
            UnifiedNetworkPacketClient.Handler handler
    ) {
        ClientServices.PLATFORM.registerClientNetworkPacketReceiver(channelName, handler);
    }

    public static void sendPacketToServer(
            class_2960 channelName,
            class_2540 buf
    ) {
        ClientServices.PLATFORM.sendNetworkPacketToServer(channelName, buf);
    }

    public static boolean canSendPacketToServer(class_2960 channelName) {
        return ClientServices.PLATFORM.canSendNetworkPacketToServer(channelName);
    }
}
