package com.github.mahmudindev.mcmod.orenocommons.client.platform.services;

import com.github.mahmudindev.mcmod.orenocommons.client.network.UnifiedNetworkPacketClient;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

public interface IClientPlatformHelper {
    void registerClientNetworkPacketReceiver(
            class_2960 channelName,
            UnifiedNetworkPacketClient.Handler handler
    );

    void sendNetworkPacketToServer(
            class_2960 channelName,
            class_2540 buf
    );

    boolean canSendNetworkPacketToServer(class_2960 channelName);
}
