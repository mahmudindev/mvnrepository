package com.github.mahmudindev.mcmod.orenocommons.client.network;

import net.minecraft.class_2540;
import net.minecraft.class_310;
import net.minecraft.class_746;

public class UnifiedNetworkPacketClient {
    public interface Context {
        class_310 client();

        class_746 player();

        void execute(Runnable task);
    }

    @FunctionalInterface
    public interface Handler {
        void handle(Context ctx, class_2540 buf);
    }
}
