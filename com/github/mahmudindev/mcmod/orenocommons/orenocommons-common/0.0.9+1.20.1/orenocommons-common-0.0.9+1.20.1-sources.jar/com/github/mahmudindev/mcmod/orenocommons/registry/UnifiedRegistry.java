package com.github.mahmudindev.mcmod.orenocommons.registry;

import com.github.mahmudindev.mcmod.orenocommons.platform.services.Services;
import java.util.function.Supplier;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;

public class UnifiedRegistry {
    public static <T, V extends T> Supplier<V> registerEntry(
            class_5321<? extends class_2378<T>> resourceKey,
            class_2960 resourceLocation,
            Supplier<? extends V> supplier
    ) {
        return Services.PLATFORM.registerRegistryEntry(
                resourceKey,
                resourceLocation,
                supplier
        );
    }
}
