package com.github.mahmudindev.mcmod.orenocommons.client.network;

import com.github.mahmudindev.mcmod.orenocommons.client.OrenoCommonsClientExpectPlatform;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

public class UnifiedNetworkClient {
    public static void registerClientPacketReceiver(
            class_2960 channelName,
            UnifiedNetworkPacketClient.Handler handler
    ) {
        OrenoCommonsClientExpectPlatform.registerClientNetworkPacketReceiver(channelName, handler);
    }

    public static void sendNetworkPacketToServer(
            class_2960 channelName,
            class_2540 buf
    ) {
        OrenoCommonsClientExpectPlatform.sendNetworkPacketToServer(channelName, buf);
    }
}
