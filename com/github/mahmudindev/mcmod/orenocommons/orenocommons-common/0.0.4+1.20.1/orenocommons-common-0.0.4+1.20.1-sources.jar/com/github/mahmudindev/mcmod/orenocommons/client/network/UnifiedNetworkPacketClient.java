package com.github.mahmudindev.mcmod.orenocommons.client.network;

import net.minecraft.class_2540;
import net.minecraft.class_310;

public class UnifiedNetworkPacketClient {
    @FunctionalInterface
    public interface Handler {
        void handle(class_310 client, class_2540 buf);
    }
}
