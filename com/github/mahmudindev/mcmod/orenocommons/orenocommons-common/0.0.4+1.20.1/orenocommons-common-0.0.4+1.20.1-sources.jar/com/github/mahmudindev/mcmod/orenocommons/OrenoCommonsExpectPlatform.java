package com.github.mahmudindev.mcmod.orenocommons;

import com.github.mahmudindev.mcmod.orenocommons.network.UnifiedNetworkPacket;
import dev.architectury.injectables.annotations.ExpectPlatform;
import java.nio.file.Path;
import java.util.function.Supplier;
import net.minecraft.class_2378;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_5321;

public class OrenoCommonsExpectPlatform {
    @ExpectPlatform
    public static String getPlatformName() {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static Path getGameDirectory() {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static Path getConfigDirectory() {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static boolean isModLoaded(String id) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static boolean isDevelopmentEnvironment() {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static <T, V extends T> Supplier<V> registerRegistryEntry(
            class_5321<? extends class_2378<T>> resourceKey,
            class_2960 resourceLocation,
            Supplier<? extends V> supplier
    ) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void registerServerNetworkPacketReceiver(
            class_2960 channelName,
            UnifiedNetworkPacket.Handler handler
    ) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void sendNetworkPacketToPlayer(
            class_3222 player,
            class_2960 channelName,
            class_2540 buf
    ) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static boolean canSendNetworkPacketToPlayer(
            class_3222 player,
            class_2960 channelName
    ) {
        throw new AssertionError();
    }
}
