package com.github.mahmudindev.mcmod.orenocommons.network;

import net.minecraft.class_2540;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

public class UnifiedPacket {
    @FunctionalInterface
    public interface Handler {
        void handle(MinecraftServer server, class_3222 player, class_2540 buf);
    }
}
