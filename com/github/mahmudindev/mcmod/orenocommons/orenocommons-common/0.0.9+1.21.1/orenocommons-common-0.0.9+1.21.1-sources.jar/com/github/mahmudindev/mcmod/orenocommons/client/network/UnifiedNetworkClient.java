package com.github.mahmudindev.mcmod.orenocommons.client.network;

import com.github.mahmudindev.mcmod.orenocommons.client.platform.services.ClientServices;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public class UnifiedNetworkClient {
    public static <T extends class_8710> void registerClientPacketReceiver(
            class_8710.class_9154<T> type,
            class_9139<class_9129, T> codec,
            UnifiedNetworkPacketClient.Handler<T> handler
    ) {
        ClientServices.PLATFORM.registerClientNetworkPacketReceiver(type, codec, handler);
    }

    public static void sendPacketToServer(class_8710 payload) {
        ClientServices.PLATFORM.sendNetworkPacketToServer(payload);
    }

    public static boolean canSendPacketToServer(class_8710.class_9154<?> type) {
        return ClientServices.PLATFORM.canSendNetworkPacketToServer(type);
    }
}
