package com.github.mahmudindev.mcmod.orenocommons.network;

import com.github.mahmudindev.mcmod.orenocommons.platform.services.Services;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public class UnifiedNetwork {
    public static <T extends class_8710> void registerServerPacketReceiver(
            class_8710.class_9154<T> type,
            class_9139<class_9129, T> codec,
            UnifiedNetworkPacket.Handler<T> handler
    ) {
        Services.PLATFORM.registerServerNetworkPacketReceiver(type, codec, handler);
    }

    public static void sendPacketToPlayer(class_3222 player, class_8710 payload) {
        Services.PLATFORM.sendNetworkPacketToPlayer(player, payload);
    }

    public static boolean canSendPacketToPlayer(
            class_3222 player,
            class_8710.class_9154<?> type
    ) {
        return Services.PLATFORM.canSendNetworkPacketToPlayer(player, type);
    }
}
