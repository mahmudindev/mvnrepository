package com.github.mahmudindev.mcmod.orenocommons.platform.services;

import com.github.mahmudindev.mcmod.orenocommons.network.UnifiedNetworkPacket;
import com.github.mahmudindev.mcmod.orenocommons.platform.EnvSide;
import java.nio.file.Path;
import java.util.function.Supplier;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public interface IPlatformHelper {
    String getPlatformName();

    Path getGameDir();

    Path getConfigDir();

    boolean isModLoaded(String id);

    EnvSide getEnvSide();

    boolean isDevelopmentEnvironment();

    <T, V extends T> Supplier<V> registerRegistryEntry(
            class_5321<? extends class_2378<T>> resourceKey,
            class_2960 resourceLocation,
            Supplier<? extends V> supplier
    );

    <T extends class_8710> void registerServerNetworkPacketReceiver(
            class_8710.class_9154<T> type,
            class_9139<? super class_9129, T> codec,
            UnifiedNetworkPacket.Handler<T> handler
    );

    void sendNetworkPacketToPlayer(class_3222 player, class_8710 payload);

    boolean canSendNetworkPacketToPlayer(
            class_3222 player,
            class_8710.class_9154<?> type
    );
}
