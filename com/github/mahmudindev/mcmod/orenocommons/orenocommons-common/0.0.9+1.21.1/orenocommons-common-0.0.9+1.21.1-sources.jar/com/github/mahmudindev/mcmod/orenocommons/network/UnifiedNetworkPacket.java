package com.github.mahmudindev.mcmod.orenocommons.network;

import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.server.MinecraftServer;

public class UnifiedNetworkPacket {
    public interface Context {
        MinecraftServer server();

        class_3222 player();

        void execute(Runnable task);
    }

    @FunctionalInterface
    public interface Handler<T extends class_8710> {
        void handle(Context ctx, T payload);
    }
}
