package com.github.mahmudindev.mcmod.orenocommons.client.platform.services;

import com.github.mahmudindev.mcmod.orenocommons.client.network.UnifiedNetworkPacketClient;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public interface IClientPlatformHelper {
    <T extends class_8710> void registerClientNetworkPacketReceiver(
            class_8710.class_9154<T> type,
            class_9139<? super class_9129, T> codec,
            UnifiedNetworkPacketClient.Handler<T> handler
    );

    void sendNetworkPacketToServer(class_8710 payload);

    boolean canSendNetworkPacketToServer(class_8710.class_9154<?> type);
}
