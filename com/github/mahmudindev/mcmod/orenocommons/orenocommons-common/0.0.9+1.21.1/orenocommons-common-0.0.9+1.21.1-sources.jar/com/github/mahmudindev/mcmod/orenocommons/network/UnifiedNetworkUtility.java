package com.github.mahmudindev.mcmod.orenocommons.network;

import io.netty.buffer.Unpooled;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.function.Consumer;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import net.minecraft.class_2540;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public class UnifiedNetworkUtility {
    public static <T> class_9139<class_9129, T> createCompressedCodec(
            class_9139<class_9129, T> innerCodec,
            int maxUncompressedSize
    ) {
        return class_9139.method_56437(
                (buf, value) -> {
                    class_9129 bufX = new class_9129(
                            Unpooled.buffer(),
                            buf.method_56349()
                    );

                    try {
                        innerCodec.encode(bufX, value);

                        writeCompressedBuffer(buf, bufZ -> bufZ.method_52975(bufX));
                    } finally {
                        bufX.release();
                    }
                },
                buf -> {
                    class_9129 bufX = new class_9129(
                            Unpooled.buffer(),
                            buf.method_56349()
                    );

                    try {
                        readCompressedBuffer(
                                buf,
                                bufZ -> bufZ.method_52956(bufX),
                                maxUncompressedSize
                        );

                        return innerCodec.decode(bufX);
                    } finally {
                        bufX.release();
                    }
                }
        );
    }

    public static void writeCompressedBuffer(
            class_2540 buf,
            Consumer<class_2540> payload
    ) {
        class_2540 bufX = new class_2540(Unpooled.buffer());

        try {
            payload.accept(bufX);

            byte[] bytes = new byte[bufX.readableBytes()];
            bufX.method_52979(bytes);

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            try (GZIPOutputStream gzip = new GZIPOutputStream(baos)) {
                gzip.write(bytes);
                gzip.finish();
            } catch (IOException e) {
                throw new RuntimeException("Write compressed packet payload failed", e);
            }

            byte[] bytesX = baos.toByteArray();
            buf.method_10804(bytesX.length);
            buf.method_52983(bytesX);
        } finally {
            bufX.release();
        }
    }

    public static void readCompressedBuffer(
            class_2540 buf,
            Consumer<class_2540> payload,
            int maxUncompressedSize
    ) {
        class_2540 bufX = new class_2540(Unpooled.buffer());

        try {
            int length = buf.method_10816();
            byte[] bytes = new byte[length];
            buf.method_52979(bytes);

            ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
            try (GZIPInputStream gzip = new GZIPInputStream(bais)) {
                byte[] bytesX = gzip.readNBytes(maxUncompressedSize + 1);

                if (bytesX.length > maxUncompressedSize) {
                    throw new IOException("Compressed packet payload too large");
                }

                bufX.method_52983(bytesX);
            } catch (IOException e) {
                throw new RuntimeException("Read compressed packet payload failed", e);
            }

            payload.accept(bufX);
        } finally {
            bufX.release();
        }
    }
}
