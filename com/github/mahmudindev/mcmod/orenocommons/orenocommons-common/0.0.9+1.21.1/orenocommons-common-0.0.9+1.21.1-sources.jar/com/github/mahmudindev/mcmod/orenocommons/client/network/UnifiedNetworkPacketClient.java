package com.github.mahmudindev.mcmod.orenocommons.client.network;

import net.minecraft.class_310;
import net.minecraft.class_746;
import net.minecraft.class_8710;

public class UnifiedNetworkPacketClient {
    public interface Context {
        class_310 client();

        class_746 player();

        void execute(Runnable task);
    }

    @FunctionalInterface
    public interface Handler<T extends class_8710> {
        void handle(Context ctx, T payload);
    }
}
