package com.github.mahmudindev.mcmod.orenocommons.fabric;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import java.nio.file.Path;
import java.util.function.Supplier;

public class OrenoCommonsExpectPlatformImpl {
    private static final FabricLoader LOADER = FabricLoader.getInstance();

    public static String getPlatformName() {
        return "Fabric";
    }

    public static Path getGameDirectory() {
        return LOADER.getGameDir();
    }

    public static Path getConfigDirectory() {
        return LOADER.getConfigDir();
    }

    public static boolean isModLoaded(String id) {
        return LOADER.isModLoaded(id);
    }

    public static boolean isDevelopmentEnvironment() {
        return LOADER.isDevelopmentEnvironment();
    }

    public static <T, V extends T> Supplier<V> registerRegistryEntry(
            class_5321<? extends class_2378<T>> resourceKey,
            class_2960 resourceLocation,
            Supplier<? extends V> supplier
    ) {
        class_2378<?> registry = class_7923.field_41167.method_10223(resourceKey.method_29177());
        if (registry == null) {
            throw new IllegalStateException("Unable to find the registry.");
        }

        //noinspection unchecked
        class_2378<T> registryX = (class_2378<T>) registry;
        V registered = class_2378.method_10230(registryX, resourceLocation, supplier.get());

        return () -> registered;
    }
}
