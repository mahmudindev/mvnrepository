package com.github.mahmudindev.mcmod.orenocommons.fabric.client.platform.services;

import com.github.mahmudindev.mcmod.orenocommons.client.network.UnifiedNetworkPacketClient;
import com.github.mahmudindev.mcmod.orenocommons.client.platform.services.IClientPlatformHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_310;
import net.minecraft.class_746;
import net.minecraft.class_8710;

public class FabricClientPlatformHelper implements IClientPlatformHelper {
    @Override
    public <T extends class_8710> void registerClientNetworkPacketReceiver(
            class_8710.class_9154<T> type,
            UnifiedNetworkPacketClient.Handler<T> handler
    ) {
        ClientPlayNetworking.registerGlobalReceiver(
                type,
                (payload, context) -> {
                    handler.handle(new UnifiedNetworkPacketClient.Context() {
                        @Override
                        public class_310 client() {
                            return context.client();
                        }

                        @Override
                        public class_746 player() {
                            return context.player();
                        }

                        @Override
                        public void execute(Runnable task) {
                            class_310 client = context.client();
                            if (client.method_18854()) {
                                task.run();
                            } else {
                                client.execute(task);
                            }
                        }
                    }, payload);
                }
        );
    }

    @Override
    public void sendNetworkPacketToServer(class_8710 payload) {
        ClientPlayNetworking.send(payload);
    }

    @Override
    public boolean canSendNetworkPacketToServer(class_8710.class_9154<?> type) {
        return ClientPlayNetworking.canSend(type);
    }
}
