package com.github.mahmudindev.mcmod.orenocommons.fabric.platform.services;

import com.github.mahmudindev.mcmod.orenocommons.platform.EnvSide;
import com.github.mahmudindev.mcmod.orenocommons.network.UnifiedNetworkPacket;
import com.github.mahmudindev.mcmod.orenocommons.platform.services.IPlatformHelper;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2378;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.server.MinecraftServer;
import java.nio.file.Path;
import java.util.function.Supplier;

public class FabricPlatformHelper implements IPlatformHelper {
    private static final FabricLoader LOADER = FabricLoader.getInstance();

    @Override
    public String getPlatformName() {
        return "Fabric";
    }

    @Override
    public Path getGameDir() {
        return LOADER.getGameDir();
    }

    @Override
    public Path getConfigDir() {
        return LOADER.getConfigDir();
    }

    @Override
    public boolean isModLoaded(String id) {
        return LOADER.isModLoaded(id);
    }

    @Override
    public EnvSide getEnvSide() {
        switch (LOADER.getEnvironmentType()) {
            case CLIENT -> {
                return EnvSide.CLIENT;
            }
            case SERVER -> {
                return EnvSide.DEDICATED_SERVER;
            }
        }

        return null;
    }

    @Override
    public boolean isDevelopmentEnvironment() {
        return LOADER.isDevelopmentEnvironment();
    }

    @Override
    public <T, V extends T> Supplier<V> registerRegistryEntry(
            class_5321<? extends class_2378<T>> resourceKey,
            class_2960 resourceLocation,
            Supplier<? extends V> supplier
    ) {
        class_2378<?> registry = class_7923.field_41167.method_10223(resourceKey.method_29177());
        if (registry == null) {
            throw new IllegalStateException("Unable to find the registry.");
        }

        //noinspection unchecked
        class_2378<T> registryX = (class_2378<T>) registry;
        V registered = class_2378.method_10230(registryX, resourceLocation, supplier.get());

        return () -> registered;
    }

    @Override
    public void registerServerNetworkPacketReceiver(
            class_2960 channelName,
            UnifiedNetworkPacket.Handler handler
    ) {
        ServerPlayNetworking.registerGlobalReceiver(
                channelName,
                (server, player, handlerX, buf, responseSender) -> {
                    handler.handle(new UnifiedNetworkPacket.Context() {
                        @Override
                        public MinecraftServer server() {
                            return server;
                        }

                        @Override
                        public class_3222 player() {
                            return player;
                        }

                        @Override
                        public void execute(Runnable task) {
                            if (server.method_18854()) {
                                task.run();
                            } else {
                                server.execute(task);
                            }
                        }
                    }, buf);
                }
        );
    }

    @Override
    public void sendNetworkPacketToPlayer(
            class_3222 player,
            class_2960 channelName,
            class_2540 buf
    ) {
        ServerPlayNetworking.send(player, channelName, buf);
    }

    @Override
    public boolean canSendNetworkPacketToPlayer(
            class_3222 player,
            class_2960 channelName
    ) {
        return ServerPlayNetworking.canSend(player, channelName);
    }
}
