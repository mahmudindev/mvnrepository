package com.github.mahmudindev.mcmod.orenocommons.fabric.client;

import com.github.mahmudindev.mcmod.orenocommons.client.network.UnifiedNetworkPacketClient;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

public class OrenoCommonsClientExpectPlatformImpl {
    public static void registerClientNetworkPacketReceiver(
            class_2960 channelName,
            UnifiedNetworkPacketClient.Handler handler
    ) {
        ClientPlayNetworking.registerGlobalReceiver(
                channelName,
                (client, handlerX, buf, sender) -> {
                    handler.handle(client, buf);
                }
        );
    }

    public static void sendNetworkPacketToServer(
            class_2960 channelName,
            class_2540 buf
    ) {
        ClientPlayNetworking.send(channelName, buf);
    }

    public static boolean canSendNetworkPacketToServer(class_2960 channelName) {
        return ClientPlayNetworking.canSend(channelName);
    }
}
