package com.github.mahmudindev.mcmod.orenocommons.fabric.platform.services;

import com.github.mahmudindev.mcmod.orenocommons.platform.EnvSide;
import com.github.mahmudindev.mcmod.orenocommons.network.UnifiedNetworkPacket;
import com.github.mahmudindev.mcmod.orenocommons.platform.services.IPlatformHelper;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.server.MinecraftServer;
import java.nio.file.Path;
import java.util.function.Supplier;

public class FabricPlatformHelper implements IPlatformHelper {
    private static final FabricLoader LOADER = FabricLoader.getInstance();

    @Override
    public String getPlatformName() {
        return "Fabric";
    }

    @Override
    public Path getGameDir() {
        return LOADER.getGameDir();
    }

    @Override
    public Path getConfigDir() {
        return LOADER.getConfigDir();
    }

    @Override
    public boolean isModLoaded(String id) {
        return LOADER.isModLoaded(id);
    }

    @Override
    public EnvSide getEnvSide() {
        switch (LOADER.getEnvironmentType()) {
            case CLIENT -> {
                return EnvSide.CLIENT;
            }
            case SERVER -> {
                return EnvSide.DEDICATED_SERVER;
            }
        }

        return null;
    }

    @Override
    public boolean isDevelopmentEnvironment() {
        return LOADER.isDevelopmentEnvironment();
    }

    @Override
    public <T, V extends T> Supplier<V> registerRegistryEntry(
            class_5321<? extends class_2378<T>> resourceKey,
            class_2960 resourceLocation,
            Supplier<? extends V> supplier
    ) {
        class_2378<?> registry = class_7923.field_41167.method_10223(resourceKey.method_29177());
        if (registry == null) {
            throw new IllegalStateException("Unable to find the registry.");
        }

        //noinspection unchecked
        class_2378<T> registryX = (class_2378<T>) registry;
        V registered = class_2378.method_10230(registryX, resourceLocation, supplier.get());

        return () -> registered;
    }

    @Override
    public <T extends class_8710> void registerServerNetworkPacketReceiver(
            class_8710.class_9154<T> type,
            class_9139<? super class_9129, T> codec,
            UnifiedNetworkPacket.Handler<T> handler
    ) {
        PayloadTypeRegistry.playC2S().register(type, codec);

        ServerPlayNetworking.registerGlobalReceiver(
                type,
                (payload, context) -> {
                    handler.handle(new UnifiedNetworkPacket.Context() {
                        @Override
                        public MinecraftServer server() {
                            return context.server();
                        }

                        @Override
                        public class_3222 player() {
                            return context.player();
                        }

                        @Override
                        public void execute(Runnable task) {
                            MinecraftServer server = context.server();
                            if (server.method_18854()) {
                                task.run();
                            } else {
                                server.execute(task);
                            }
                        }
                    }, payload);
                }
        );
    }

    @Override
    public void sendNetworkPacketToPlayer(class_3222 player, class_8710 payload) {
        ServerPlayNetworking.send(player, payload);
    }

    @Override
    public boolean canSendNetworkPacketToPlayer(
            class_3222 player,
            class_8710.class_9154<?> type
    ) {
        return ServerPlayNetworking.canSend(player, type);
    }
}
